<div class="wrap">
<h1>Products Api</h1>
<form method="post" action="options.php" novalidate="novalidate">
<table class="form-table" role="presentation">
<tbody>
<tr>
<th scope="row"><label for="siteurl">Get All Product</label></th>
<td><p>"<?php echo get_site_url(); ?>/wp-json/product-api/v1/products"</p>
<p class="description" id="home-description1">(Use for get all products)</p>
</td>
</tr>
<tr>
<th scope="row"><label for="home">Get Single Product</label></th>
<td><p>"<?php echo get_site_url(); ?>/wp-json/product-api/v1/products/{id}"</p>
<p class="description" id="home-description">(Use for get single product)</p>
</td>
</tr>
</tbody>
</table>
</div>