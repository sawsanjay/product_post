<?php
class Custom_Admin_Product_Api_Submenu {

    public function __construct() {
        add_action('admin_menu', array($this, 'custom_product_api_submenu'));
    }

    public function custom_product_api_submenu() {
      add_submenu_page(
        'edit.php?post_type=product',
        'Api',
        'Api',
        'manage_options',
        'products_api',
        [$this, 'custom_post_type_submenu_callback']
      );
    }

    public function custom_post_type_submenu_callback($request) {
      include_once( PRODUCTPOST__PLUGIN_DIR . 'admin/product-api-view.php' );
    }
}
$Custom_Admin_Product_Api_Submenu = new Custom_Admin_Product_Api_Submenu();
    
    
