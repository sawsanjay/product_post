 
<?php
get_header(); 
?>
<section>
	<div class="row">

		<div class="col-lg-9 col-md-8 col-sm-12">
			<div class="product_list">
				<div class="row posts-area">
				</div><br>
				<div class="d-flex justify-content-center " style="text-align: center;">
					<a href="#"  id="product_load_ready"  class="btn-outline-primary product_loadmore_ready"><button type="button" class="btn btn-danger">Load More</button></a>
				</div>
			</div>
		</div>

		<div class="col-lg-3 col-md-4 col-sm-12">
			<form id="product-filter" method="POST">
				<div class="product_cat_main ">
					<label style="width: 100%">Category: </label>
					<?php
					$args = array( 'taxonomy' => 'product_category', 'orderby' => 'name', 'order' => 'ASC' );
					$categories = get_categories($args);
					foreach($categories as $category) { ?> 
						<input type="checkbox" name="category[]" value="<?php echo $category->name; ?>"> <?php echo strtoupper($category->name) ; ?><br>
					<?php  
					} ?>
				</div> 
				<div class="product_cat_main ">
					<label style="width: 100%">Colors: </label>
					<?php
					$args = array( 'taxonomy' => 'product_color', 'orderby' => 'name', 'order' => 'ASC' );
					$categories = get_categories($args);
					foreach($categories as $category) { ?> 
						<input type="checkbox" name="color[]" value="<?php echo $category->name; ?>"> <?php echo strtoupper($category->name) ; ?><br>
					<?php  
					} ?>
				</div> 
				<div class="product_cat_main ">
					<label style="width: 100%">Size: </label>
					<?php
					$args = array( 'taxonomy' => 'product_size', 'orderby' => 'name', 'order' => 'ASC' );
					$categories = get_categories($args);
					foreach($categories as $category) { ?> 
						<input type="checkbox" name="size[]" value="<?php echo $category->name; ?>"> <?php echo strtoupper($category->name) ; ?><br>
					<?php  
					} ?>
				</div> 
				<div style="text-align:right;"><input type="submit"  value="Filter"></div>
				<div style="text-align:left;"><a href="<?php echo get_site_url()?>/product" >Clear Filter</a></div>
			</form>
		</div>
	</div>
</section>
<?php get_footer(); ?>