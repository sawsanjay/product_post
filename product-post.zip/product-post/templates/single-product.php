<?php
/**
 * Template Name: Single Product
 * Template Post Type: product
 */
get_header(); 
?>
  <div class="container">
  <h1>Product Page</h1>
  <hr>
  <br><br>
    <div class="row">
      <div class="col-md-6">
      <img src="<?php if (!empty(get_the_post_thumbnail_url(get_the_ID(), 'full'))) {
                          echo get_the_post_thumbnail_url(get_the_ID(), 'full');
                        } else {
                          echo get_site_url(); ?>/wp-content/uploads/2022/08/defualt.jpg<?php } ?>" alt="<?php echo get_post_meta(get_post_thumbnail_id(get_the_ID()), '_wp_attachment_image_alt', true); ?>">
      </div>
      <div class="col-md-6">
        <h3><?php echo get_the_title(); ?></h3>
        <p><?php if (!empty(get_the_excerpt())) {
                    echo wp_trim_words(get_the_excerpt(), 20, '...');
                  } else {
                    echo wp_trim_words(get_the_content(), 20, '...');
                  } ?></p>
    
        <?php if (is_user_logged_in()) : ?>
              <?php
                  $post_id = get_the_ID();
                  $wishlist_item = get_page_by_title(get_the_title($post_id), OBJECT, 'wishlist');
                  $wishlist_item_id = $wishlist_item ? $wishlist_item->ID : 0;
                  $args = array('remove_from_wishlist' => 'true', 'wishlist_id' => $wishlist_item_id,);
                  $args_add = array('add_to_wishlist' => 'true', 'product_id' => $post_id, );
                  $wishlist_text = $wishlist_item_id ? 'Remove From Wishlist' : 'Add To Wishlist';
                  $wishlist_url = $wishlist_item_id ? add_query_arg($args, get_permalink()) : add_query_arg($args_add, get_the_permalink());
              ?>
              <a href="<?php echo esc_url($wishlist_url); ?>" class="wishlist-button btn btn-primary"><?php echo esc_html($wishlist_text); ?></a>
        <?php endif; ?>
      </div>
    </div>
  </div>
<?php
get_footer();
?>
