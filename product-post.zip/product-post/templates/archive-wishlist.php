<?php
/*
 * Template Name: Wishlist Archive
 * Description: Custom template for displaying wishlist items in a table format.
 */

get_header(); ?>

<section id="primary" class="content-area">
  <main id="main" class="site-main">
    <?php
    $current_user = wp_get_current_user();
    $wishlist_args = array(
        'post_type' => 'wishlist',
        'author' => $current_user->ID,
        'posts_per_page' => -1,
    );
    // Create a new WP_Query instance
    $query = new WP_Query( $wishlist_args );

    if ( $query->have_posts() ) : ?>
      <table>
        <thead>
          <tr>
            <th>No</th>
            <th>Title</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php 
          $n = 1;
          while ( $query->have_posts() ) : $query->the_post(); ?>
            <tr>
              <td><?php echo $n; $n++ ?></td>
              <td><?php the_title(); ?></td>
              <td><?php if (is_user_logged_in()) : ?>
                <?php
                    $post_id = get_the_ID();
                    $wishlist_item = get_page_by_title(get_the_title($post_id), OBJECT, 'wishlist');
                    $wishlist_item_id = $wishlist_item ? $wishlist_item->ID : 0;
                    $args = array(
                        'remove_from_wishlist' => 'true',
                        'wishlist_id' => $wishlist_item_id,
                    );
                    $wishlist_text = $wishlist_item_id ? 'Remove From Wishlist' : 'Add To Wishlist';
                    $wishlist_url = $wishlist_item_id ? add_query_arg($args, get_permalink()) : get_the_permalink() . '?add_to_wishlist=true';
                ?>
                <a href="<?php echo esc_url($wishlist_url); ?>" class="wishlist-button btn btn-primary"><?php echo esc_html($wishlist_text); ?></a>
                <?php endif; ?></td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    <?php else : ?>
      <p>No wishlist items found.</p>
    <?php endif;

    // Restore original post data
    wp_reset_postdata();
    ?>
  </main><!-- #main -->
</section><!-- #primary -->

<?php get_footer(); ?>
