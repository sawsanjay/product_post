jQuery(document).ready(function($) {
    $('#product_load_ready').hide();
    $('#product-filter').submit(function(e) {
        e.preventDefault();

        var data = {
            action: 'filter_products',
            color: $('input[name="color[]"]:checked').map(function() {
                return this.value;
            }).get(),
            category: $('input[name="category[]"]:checked').map(function() {
                return this.value;
            }).get(),
            size: $('input[name="size[]"]:checked').map(function() {
                return this.value;
            }).get()
        };
        
        $.ajax({
            url: ajax_object.ajax_url,
            type: 'POST',
            data: data,
            success: function(response) {
                $('.posts-area').html(response);
                $('#product_load_ready').hide();
            },
            error: function(xhr, ajaxOptions, thrownError) {
                alert('An error occurred. Please try again.');
            }
        });
    });
});

jQuery(document).ready(function() {
  window.rbl_page = 2;
 jQuery('#product_search_load').hide();
 jQuery('#product_category_load').hide();
 jQuery('#mobile_category_load').hide();
  jQuery.ajax({
      type: 'POST',
      url: ajax_object.ajax_url,
      dataType: "html",
      data: {
          action: 'get_ajax_posts', 'post_type':'product', 'task': 'ready_product'
      },
      success: function(response) {
          jQuery('.load_more').html('<a  id="product_load_ready" class="btn-outline-primary product_loadmore_ready"><span>Load More<i class="fa-solid fa-arrow-down ms-2"></i></span></a>');
          jQuery('.posts-area').html(response);
          var vs_count = jQuery('.r_count').data('id');
          var only_six = jQuery('.only_six').data('id');
          var for_six_vs = jQuery('.mlc_not_found').data('id');
          if (vs_count < 9) {
              jQuery('.product_loadmore_ready').hide();
          } else {
              if (for_six_vs == 0) {
                  jQuery('.product_loadmore_ready').hide();
              } else {
              if(only_six == 9){
                      jQuery('.product_loadmore_ready').hide();
                  } else {
                      jQuery('.product_loadmore_ready').show();
                  }
              }
          }
      }

  });
  return false;
});

jQuery(document).on('click', '#product_load_ready', function() {
  jQuery.ajax({
      type: 'POST',
      url: ajax_object.ajax_url,
      dataType: "html",
      data: {
          action: 'get_ajax_posts', 'post_type':'product', 'm_page': rbl_page, 'task': 'ready_product'
      }, 
      beforeSend: function(xhr) {
          jQuery('.load_more').html('<span class="spinner-border text-primary" role="status"></span>');
      },
      success: function(response) {
          jQuery('.load_more').html('<a  id="product_load_ready" class="btn-outline-primary product_loadmore_ready"><span>Load More<i class="fa-solid fa-arrow-down ms-2"></i></span></a>');
          jQuery('.posts-area').append(response);
          var vs_count = jQuery('.r_count'+rbl_page).data('id');
          var for_six_vs = jQuery('.mlc_not_found').data('id');
          if (vs_count < 9) {
              jQuery('.product_loadmore_ready').hide();
          } else {
              if (for_six_vs == 0) {
                  jQuery('.product_loadmore_ready').hide();
              } else {
                  jQuery('.product_loadmore_ready').show();
              }
          }
          rbl_page++;
      }
  });
  return false;
});






