<?php 
/**
 * Plugin Name: Product Post
 * Description: A plugin for adding product custom post type functionality to your WordPress site. when you activate this plugin, create a product page, as an archive page for resources.
 * Version: 1.0
 * Author: sanjay saw
 * Author URI: http://google.com
 * Text Domain: product-post
 */
 
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

define( 'PRODUCTPOST_VERSION', '5.1' );
define( 'PRODUCTPOST__MINIMUM_WP_VERSION', '5.0' );
define( 'PRODUCTPOST__PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'PRODUCTPOST_DELETE_LIMIT', 10000 );

function enqueue_product_scripts() {
  wp_enqueue_style( 'product-post-plugin-css',plugin_dir_url( __FILE__ ) . 'assets/css/product-post-style.css', '1.1.0', true );
  wp_enqueue_script('jquery');
  wp_enqueue_script( 'jquery-validate', 'http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js', array( 'jquery' ), '1.19.3', true );
  wp_enqueue_script('product-archive-script', plugin_dir_url( __FILE__ ) . 'assets/js/product-archive.js', array('jquery'), '1.0', true);
  wp_localize_script('product-archive-script', 'ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
}
add_action('wp_enqueue_scripts', 'enqueue_product_scripts');

require_once( PRODUCTPOST__PLUGIN_DIR . 'classes/class.custom-post.php' );
require_once( PRODUCTPOST__PLUGIN_DIR . 'classes/class.archive-page-ajax.php');
require_once( PRODUCTPOST__PLUGIN_DIR . 'classes/class.custom-wishlist.php');
require_once( PRODUCTPOST__PLUGIN_DIR . 'classes/class.custom-product-api.php');
require_once( PRODUCTPOST__PLUGIN_DIR . 'classes/class.custom-admin-product-api-submenu.php');
require_once( PRODUCTPOST__PLUGIN_DIR . 'classes/class.custom-product-single-template.php');
require_once( PRODUCTPOST__PLUGIN_DIR . 'classes/class.custom-shortcodes.php');

register_activation_hook( __FILE__, 'activate');
register_deactivation_hook( __FILE__,'deactivate');

function activate() {
 add_product_archive_page();
 add_wishlist_archive_page();
}

function deactivate() {
  delete_my_all_custom_archive_page();
}

function add_product_archive_page() {
  $page_title = 'product';
  $page_content = '[product_archive]';
  $page = array(
      'post_title'     => $page_title,
      'post_content'   => $page_content,
      'post_status'    => 'publish',
      'post_type'      => 'page',
      'post_author'    => 1,
      'post_name'      => 'product'
  );
  wp_insert_post( $page );
}
function add_wishlist_archive_page() {
  $page_title = 'wishlist';
  $page_content = '[wishlist_archive]';
  $page = array(
      'post_title'     => $page_title,
      'post_content'   => $page_content,
      'post_status'    => 'publish',
      'post_type'      => 'page',
      'post_author'    => 1,
      'post_name'      => 'wishlist'
  );
  wp_insert_post( $page );
}
function delete_my_all_custom_archive_page() {
  wp_delete_post(get_page_by_path('product')->ID, true);
  wp_delete_post(get_page_by_path('wishlist')->ID, true);
}


add_action('wp_ajax_filter_products', 'filter_products');
add_action('wp_ajax_nopriv_filter_products', 'filter_products');




?>