<?php
class Custom_Product_Single_Template {

  public function __construct() {
    add_filter('single_template', array($this, 'product_single_template'));
  }

  public function product_single_template($single_template) {
    global $post;
    if ($post->post_type == 'product') {
        $single_template = PRODUCTPOST__PLUGIN_DIR . 'templates/single-product.php';
    }
    return $single_template;
  }
}
$Custom_Product_Single_Template = new Custom_Product_Single_Template();
    
    
