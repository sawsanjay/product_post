<?php

class Custom_Post {
    public function __construct() {
        add_action('init', array($this, 'register_custom_post_type'));
    }

    public function register_custom_post_type() {
        register_post_type('product', [
            'label' => __('Products', 'txtdomain'),
            'public' => true,
            'menu_position' => 5,
            'menu_icon' => 'dashicons-book',
            'supports' => ['title', 'editor', 'thumbnail', 'author', 'revisions', 'comments'],
            'show_in_rest' => true,
            'rewrite' => ['slug' => 'product'],
            'taxonomies' => ['product_category', 'product_color', 'product_size'],
            'labels' => [
                'singular_name' => __('Products', 'txtdomain'),
                'add_new_item' => __('Add new product', 'txtdomain'),
                'new_item' => __('New product', 'txtdomain'),
                'view_item' => __('View product', 'txtdomain'),
                'not_found' => __('No products found', 'txtdomain'),
                'not_found_in_trash' => __('No products found in trash', 'txtdomain'),
                'all_items' => __('All products', 'txtdomain'),
                'insert_into_item' => __('Insert into product', 'txtdomain')
            ],		
        ]);
        register_taxonomy('product_category', ['product'], [
            'label' => __('Category', 'txtdomain'),
            'hierarchical' => true,
            'rewrite' => ['slug' => 'product-category'],
            'show_admin_column' => true,
            'show_in_rest' => true,
            'labels' => [
                'singular_name' => __('Category', 'txtdomain'),
                'all_items' => __('All Categorys', 'txtdomain'),
                'edit_item' => __('Edit Category', 'txtdomain'),
                'view_item' => __('View Category', 'txtdomain'),
                'update_item' => __('Update Category', 'txtdomain'),
                'add_new_item' => __('Add New Category', 'txtdomain'),
                'new_item_name' => __('New Category Name', 'txtdomain'),
                'search_items' => __('Search Categorys', 'txtdomain'),
                'popular_items' => __('Popular Categorys', 'txtdomain'),
                'separate_items_with_commas' => __('Separate Categorys with comma', 'txtdomain'),
                'choose_from_most_used' => __('Choose from most used Categorys', 'txtdomain'),
                'not_found' => __('No Categorys found', 'txtdomain'),
            ]
        ]);
        register_taxonomy_for_object_type('product_category', 'product');
        register_taxonomy('product_color', ['product'], [
            'label' => __('Color', 'txtdomain'),
            'hierarchical' => true,
            'rewrite' => ['slug' => 'product-color'],
            'show_admin_column' => true,
            'show_in_rest' => true,
            'labels' => [
                'singular_name' => __('Color', 'txtdomain'),
                'all_items' => __('All Colors', 'txtdomain'),
                'edit_item' => __('Edit Color', 'txtdomain'),
                'view_item' => __('View Color', 'txtdomain'),
                'update_item' => __('Update Color', 'txtdomain'),
                'add_new_item' => __('Add New Color', 'txtdomain'),
                'new_item_name' => __('New Color Name', 'txtdomain'),
                'search_items' => __('Search Colors', 'txtdomain'),
                'parent_item' => __('Parent Color', 'txtdomain'),
                'parent_item_colon' => __('Parent Color:', 'txtdomain'),
                'not_found' => __('No Colors found', 'txtdomain'),
            ]
        ]);
        register_taxonomy_for_object_type('product_color', 'product');
        register_taxonomy('product_size', ['product'], [
            'label' => __('Size', 'txtdomain'),
            'hierarchical' => true,
            'rewrite' => ['slug' => 'product-size'],
            'show_admin_column' => true,
            'show_in_rest' => true,
            'labels' => [
                'singular_name' => __('Size', 'txtdomain'),
                'all_items' => __('All Sizes', 'txtdomain'),
                'edit_item' => __('Edit Size', 'txtdomain'),
                'view_item' => __('View Size', 'txtdomain'),
                'update_item' => __('Update Size', 'txtdomain'),
                'add_new_item' => __('Add New Size', 'txtdomain'),
                'new_item_name' => __('New Size Name', 'txtdomain'),
                'search_items' => __('Search Sizes', 'txtdomain'),
                'popular_items' => __('Popular Sizes', 'txtdomain'),
                'separate_items_with_commas' => __('Separate Sizes with comma', 'txtdomain'),
                'choose_from_most_used' => __('Choose from most used Sizes', 'txtdomain'),
                'not_found' => __('No Sizes found', 'txtdomain'),
            ]
        ]);
        register_taxonomy_for_object_type('product_size', 'product');
        register_post_type('wishlist', [
            'label' => __('Wishlist', 'txtdomain'),
            'public' => true,
            'menu_position' => 6,
            'menu_icon' => 'dashicons-heart',
            'supports' => ['title', 'editor', 'thumbnail', 'author', 'revisions', 'comments'],
            'show_in_rest' => true,
            'rewrite' => ['slug' => 'wishlist'],
            'labels' => [
                'singular_name' => __('Wishlist', 'txtdomain'),
                'add_new_item' => __('Add new wishlisht', 'txtdomain'),
                'new_item' => __('New wishlisht', 'txtdomain'),
                'view_item' => __('View wishlisht', 'txtdomain'),
                'not_found' => __('No wishlisht found', 'txtdomain'),
                'not_found_in_trash' => __('No wishlisht found in trash', 'txtdomain'),
                'all_items' => __('All Wishlisht', 'txtdomain'),
                'insert_into_item' => __('Insert into wishlisht', 'txtdomain')
            ],		
        ]);
    }
}
$custom_post_type = new Custom_Post();
    
    
