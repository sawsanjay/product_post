<?php

class Custom_Shortcodes {
    public function __construct() {
      add_shortcode('product_archive', array($this, 'product_archive_shortcode'));
      add_shortcode('wishlist_archive', array($this, 'wishlist_archive_shortcode'));
    }

    public function product_archive_shortcode() {
      ob_start();
      require_once( PRODUCTPOST__PLUGIN_DIR . 'templates/archive-product.php');
      return ob_get_clean();
    }

    public function wishlist_archive_shortcode() {
      ob_start();
      require_once( PRODUCTPOST__PLUGIN_DIR . 'templates/archive-wishlist.php');
      return ob_get_clean();
    }
}
$Custom_Shortcodes = new Custom_Shortcodes();
    
    
