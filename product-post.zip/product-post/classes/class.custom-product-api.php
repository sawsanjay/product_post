<?php
class Custom_Product_Api {

    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
    }

    public function register_routes() {
        register_rest_route( 'product-api/v1', '/products/(?P<id>\d+)', array(
            'methods'  => 'GET',
            'callback' =>  [$this, 'get_products'],
        ) );
        register_rest_route( 'product-api/v1', '/products', array(
          'methods'  => 'GET',
          'callback' =>  [$this, 'get_products'],
        ) );
    }

    public function get_products($request) {
  
        if(isset($request['id'])){
          $product_id = $request['id'];
          $args = array(
            'post_type' => 'product',
            'posts_per_page' => 1,
            'post__in'=> array($product_id)
           );
        }
        else{
          $args = array(
            'post_type'      => 'product',
            'posts_per_page' => -1,
          );
        }
      
        $products = get_posts( $args );
        if ($products) {
          
          $formatted_products = array();
        
          foreach ( $products as $product ) {
              $formatted_products[] = array(
                  'id'          => $product->ID,
                  'title'       => $product->post_title,
                  'description' => $product->post_content,
                  'price'       => get_post_meta( $product->ID, '_regular_price', true ),
              );
          }
          return rest_ensure_response( $formatted_products );
        } else {
            return new WP_Error('product_not_found', 'Product not found', array('status' => 404));
        }
    }
}
$Custom_Product_Api = new Custom_Product_Api();
    
    
