<?php
class Custom_Wishlist {

    public function __construct() {
        add_action('template_redirect', array($this, 'handle_wishlist_actions'));
    }

    public function handle_wishlist_actions() {
        if (isset($_GET['add_to_wishlist']) && $_GET['add_to_wishlist'] === 'true') {
            $prouct_id = $_GET['product_id'];
            $post_id = get_the_ID();
            $wishlist_item = get_page_by_title(get_the_title($post_id), OBJECT, 'wishlist');
      
            if (!$wishlist_item) {
                $wishlist_item_id = wp_insert_post(array(
                    'post_title' => get_the_title($post_id),
                    'post_type' => 'wishlist',
                    'post_status' => 'publish',
                ));
      
                if (isset($prouct_id) && !isset($_GET['all_page'])) {
                    // Redirect to wishlist item after successful addition
                    wp_redirect(get_permalink($prouct_id));
                    exit;
                }
                else{

                    wp_redirect(get_site_url().'/product/');
                    exit;
                }
            }
        } elseif (isset($_GET['remove_from_wishlist']) && $_GET['remove_from_wishlist'] === 'true') {
         
            $wishlist_item_id = $_GET['wishlist_id'];
            wp_delete_post($wishlist_item_id);
      
            // Redirect to previous page after successful removal
            wp_redirect(wp_get_referer());
            exit;
        }
    }
}

$Custom_Wishlist = new Custom_Wishlist();
    
    
