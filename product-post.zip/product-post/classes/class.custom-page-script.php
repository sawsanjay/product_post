<?php
class Custom_Page_Script {

    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_product_scripts'));
    }

    public function enqueue_product_scripts() {
        wp_enqueue_script('jquery');
        wp_enqueue_script( 'jquery-ajax', 'http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js', array( 'jquery' ), '1.19.3', true );
        wp_enqueue_script('product-archive-script', PRODUCTPOST__PLUGIN_DIR . 'assets/js/product-archive.js', array('jquery'), '1.0', true);
        wp_localize_script('product-archive-script', 'ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
    }
}
$Custom_Page_Script = new Custom_Page_Script();
    
    
