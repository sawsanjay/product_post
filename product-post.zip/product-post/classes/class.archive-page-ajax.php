<?php

class Archive_Page_Ajax {
    public function __construct() {
        add_action('wp_ajax_get_ajax_posts', array($this, 'get_ajax_posts'));
        add_action('wp_ajax_nopriv_get_ajax_posts', array($this, 'get_ajax_posts'));
        add_action('wp_ajax_filter_products', array($this, 'filter_products'));
        add_action('wp_ajax_nopriv_filter_products', array($this, 'filter_products'));
    }

    public function filter_products() {
      $args = array(
          'post_type' => 'product',
          'posts_per_page' => -1,
          'meta_query' => array(),
          'tax_query' => array()
      );
  
      if (isset($_POST['color']) && !empty($_POST['color'])) {
          $args['tax_query'][] = array(
              'taxonomy' => 'product_color',
              'field' => 'slug',
              'terms' => $_POST['color']
          );
      }
  
      if (isset($_POST['category']) && !empty($_POST['category'])) {
          $args['tax_query'][] = array(
              'taxonomy' => 'product_category',
              'field' => 'slug',
              'terms' => $_POST['category']
          );
      }
  
      if (isset($_POST['size']) && !empty($_POST['size'])) {
        $args['tax_query'][] = array(
          'taxonomy' => 'product_size',
          'field' => 'slug',
          'terms' => $_POST['size']
      );
      }
  
      $query = new WP_Query($args);
  
      if ($query->have_posts()) {
          while ($query->have_posts()) {
              $query->the_post(); ?>
              <div class="col-lg-4 col-sm-6">
              <div class="complet_pro_bx">
                <a href="<?php echo get_the_permalink(); ?>">
                  <div class="complet_pro_img">
                    <img src="<?php if (!empty(get_the_post_thumbnail_url(get_the_ID(), 'full'))) {
                                echo get_the_post_thumbnail_url(get_the_ID(), 'full');
                              } else {
                                echo get_site_url(); ?>/wp-content/uploads/2022/08/defualt.jpg<?php } ?>" alt="<?php echo get_post_meta(get_post_thumbnail_id(get_the_ID()), '_wp_attachment_image_alt', true); ?>">
                  </div>
                  <div class="complet_pro_body">
                    <h5><?php echo get_the_title(); ?></h5>
                    
                    
                    <div class="complet_pro_footer d-flex align-items-center ">
                    <a href="<?php echo get_the_permalink(); ?>" class="btn btn-success">View</a>
                    <?php if (is_user_logged_in()) : ?>
                          <?php
                              $post_id = get_the_ID();
                              $wishlist_item = get_page_by_title(get_the_title($post_id), OBJECT, 'wishlist');
                              $wishlist_item_id = $wishlist_item ? $wishlist_item->ID : 0;
                              $args = array('remove_from_wishlist' => 'true', 'wishlist_id' => $wishlist_item_id, 'all_page' => 'product');
                              $args_add = array('add_to_wishlist' => 'true', 'product_id' => $post_id, 'all_page' => 'product');
                              $wishlist_text = $wishlist_item_id ? 'Remove From Wishlist' : 'Add To Wishlist';
                              $wishlist_url = $wishlist_item_id ? add_query_arg($args, get_permalink()) : add_query_arg($args_add, get_the_permalink());
                          ?>
                          <a href="<?php echo esc_url($wishlist_url); ?>" class="wishlist-button btn btn-primary"><?php echo esc_html($wishlist_text); ?></a>
                    <?php endif; ?>
                    </div>
                  </div>
                </a>
              </div>
            </div>
    <?php }
          wp_reset_postdata();
      } else {
          echo 'No products found.';
      }
  
      die();
  }

    public function get_ajax_posts()
    {
      $post_id = $_POST['id'];
      if ('search_product' == $_POST['task']) {
        $product_title = $_POST['search_value'];
        $page = $_POST['page'];
        $limit = 9;
        $product_serch_count = 0;
        $args_search = array('post_type' => 'product', 'post_status' => 'publish', "s" => $product_title, 'order'   => 'DESC', 'posts_per_page' => $limit, 'paged' => $page,);
        $args_only_six = array('post_type' => 'product', 'post_status' => 'publish', "s" => $product_title, 'order'   => 'DESC', 'paged' => $page,);
        $result_only_six = new WP_Query($args_only_six);
        $only_six = $result_only_six->found_posts;
        $result_search = new WP_Query($args_search);
        if ($result_search->have_posts()) :
          while ($result_search->have_posts()) : $result_search->the_post(); ?>
          
            <div class="col-lg-4 col-sm-6">
              <div class="complet_pro_bx">
                <a href="<?php echo get_the_permalink(); ?>">
                  <div class="complet_pro_img">
                    <img src="<?php if (!empty(get_the_post_thumbnail_url(get_the_ID(), 'full'))) {
                                echo get_the_post_thumbnail_url(get_the_ID(), 'full');
                              } else {
                                echo get_site_url(); ?>/wp-content/uploads/2022/08/defualt.jpg<?php } ?>" alt="<?php echo get_post_meta(get_post_thumbnail_id(get_the_ID()), '_wp_attachment_image_alt', true); ?>">
                  </div>
                  <div class="complet_pro_body">
                    <h5><?php echo get_the_title(); ?></h5>
                    
                    
                    <div class="complet_pro_footer d-flex align-items-center ">
                    <a href="<?php echo get_the_permalink(); ?>" class="btn btn-success">View</a>
                    <?php if (is_user_logged_in()) : ?>
                          <?php
                              $post_id = get_the_ID();
                              $wishlist_item = get_page_by_title(get_the_title($post_id), OBJECT, 'wishlist');
                              $wishlist_item_id = $wishlist_item ? $wishlist_item->ID : 0;
                              $args = array('remove_from_wishlist' => 'true', 'wishlist_id' => $wishlist_item_id, 'all_page' => 'product');
                              $args_add = array('add_to_wishlist' => 'true', 'product_id' => $post_id, 'all_page' => 'product');
                              $wishlist_text = $wishlist_item_id ? 'Remove From Wishlist' : 'Add To Wishlist';
                              $wishlist_url = $wishlist_item_id ? add_query_arg($args, get_permalink()) : add_query_arg($args_add, get_the_permalink());
                          ?>
                          <a href="<?php echo esc_url($wishlist_url); ?>" class="wishlist-button btn btn-primary"><?php echo esc_html($wishlist_text); ?></a>
                    <?php endif; ?>
                    </div>
                  </div>
                </a>
              </div>
            </div>
        <?php
            $product_serch_count++;
          endwhile;
          if ($only_six  == 9) {
            echo '<span class="only_six" data-id="' . $only_six . '"></span>';
          } else {
          }
          if ($product_serch_count < '10') {
            echo '<span class="r_count' . $page . '" data-id="' . $product_serch_count . '"></span>';
          } else {
          }
        else :
          echo '<p class="noMorePostsFound text-center text-danger result-found bls_not_found" data-id="0">No More Search Results Found...</p>';
        endif;
        wp_reset_postdata(); ?>
    
        <?php
        die(1);
        exit;
      }
    
      if ('ready_product' == $_POST['task']) {
        $product_id = $_POST['cate_id']; 
        $m_page = $_POST['m_page'];
        $limit = 9;
        $product_mcat_count = 0;
        if ($product_id == 'all' || !empty($_POST['post_type'])) {
           
          $args_cat = array('post_type' => 'product', 'orderby' => 'post_date', 'post_status' => 'publish', 'order' => 'DESC',  'posts_per_page' => $limit, 'paged' => $m_page);
        } else {
           
           $args_cat = array('post_type' => 'product', 'orderby' => 'post_date', 'post_status' => 'publish', 'tax_query' =>  array(array('taxonomy' => 'product_size', 'field' => 'term_id',  'terms'  => $product_id)),'order' => 'DESC',  'posts_per_page' => $limit, 'paged' => $m_page);
           $args_only_six = array('post_type' => 'product', 'orderby' => 'post_date', 'post_status' => 'publish', 'tax_query' =>  array(array('taxonomy' => 'product_size', 'field' => 'term_id',  'terms'  => $product_id)), 'order' => 'DESC',  'paged' => $m_page);
          $result_only_six = new WP_Query($args_only_six);
          $only_six = $result_only_six->found_posts;
        }
        $result_search = new WP_Query($args_cat);
        if ($result_search->have_posts()) :
          while ($result_search->have_posts()) : $result_search->the_post(); ?>
            <div class="col-lg-4 col-sm-6">
              <div class="complet_pro_bx">
                <div class="complet_pro_img">
                  <img src="<?php if (!empty(get_the_post_thumbnail_url(get_the_ID(), 'full'))) {
                              echo get_the_post_thumbnail_url(get_the_ID(), 'full');
                            } else {
                              echo get_site_url(); ?>/wp-content/uploads/2022/08/defualt.jpg<?php } ?>" alt="<?php echo get_post_meta(get_post_thumbnail_id(get_the_ID()), '_wp_attachment_image_alt', true); ?>">
                </div>
                <div class="complet_pro_body">
                  <a href="<?php echo get_the_permalink(); ?>">
                    <h5><?php echo get_the_title(); ?></h5>
                  </a>
                  
                  
                  <div class="complet_pro_footer d-flex align-items-center ">
                    <a href="<?php echo get_the_permalink(); ?>" class="btn btn-success">View</a>
                    <?php if (is_user_logged_in()) : ?>
                          <?php
                              $post_id = get_the_ID();
                              $wishlist_item = get_page_by_title(get_the_title($post_id), OBJECT, 'wishlist');
                              $wishlist_item_id = $wishlist_item ? $wishlist_item->ID : 0;
                              $args = array('remove_from_wishlist' => 'true', 'wishlist_id' => $wishlist_item_id, 'all_page' => 'product');
                              $args_add = array('add_to_wishlist' => 'true', 'product_id' => $post_id, 'all_page' => 'product');
                              $wishlist_text = $wishlist_item_id ? 'Remove From Wishlist' : 'Add To Wishlist';
                              $wishlist_url = $wishlist_item_id ? add_query_arg($args, get_permalink()) : add_query_arg($args_add, get_the_permalink());
                          ?>
                          <a href="<?php echo esc_url($wishlist_url); ?>" class="wishlist-button btn btn-primary"><?php echo esc_html($wishlist_text); ?></a>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
            </div>
          <?php
            $product_mcat_count++;
          endwhile;
          if ($only_six  == 9) {
            echo '<span class="only_six" data-id="' . $only_six . '"></span>';
          } else {
          }
          if ($product_mcat_count < '10') {
            echo '<span class="r_count' . $m_page . '" data-id="' . $product_mcat_count . '"></span>';
          } else {
          }
        else :
          echo '<p class="noMorePostsFound text-center text-danger result-found mlc_not_found" data-id="0">No More products Found...</p>';
        endif;
        wp_reset_postdata();
        die(1);
        exit;
      }
    }
}

// Instantiate the plugin class
$Archive_Page_Ajax = new Archive_Page_Ajax();
    
    
